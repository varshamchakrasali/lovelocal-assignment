# Lovelocal
Lovelocal Assignment

I have used python for programming. 
